<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html>
	<head xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr">
		<meta charset="utf-8">
		<meta name="description" content="toxicologue, cosmétique, environnement, santé">

		<!-- Boostraplink -->
		<?php include('link_bootstrap.html');?>
		<title>Expert Beninois Toxicologue, Cosmétique, Environnement, Santé</title>

	</head>

	<body>
		<div id="navbar">
			
			<?php include('menu.php'); ?>
			
		</div>

		<div id="avatar">
			<!-- inclusion des composants Lewagon  -->
			<?php include('html/components/composants.html'); ?>
		</div>

		<div>
			

		</div>
	</body>
</html>